"""Compute scores for FLAME"""

from __future__ import annotations
from FLAME_plugin import flam_predict

__all__ = [
    "flame_abs",
    "flame_emi",
    "flame_e",
    "flame_plqy",
    'stokes',
]

from dataclasses import dataclass
from typing import List

from rdkit import Chem
import numpy as np

from .component_results import ComponentResults
from reinvent_plugins.mol_cache import molcache
from .add_tag import add_tag
import torch
import numpy as np
from rdkit import Chem


@add_tag("__parameters")
@dataclass
class Parameters:
    """Parameters for the scoring component

    Note that all parameters are always lists because components can have
    multiple endpoints and so all the parameters from each endpoint is
    collected into a list.  This is also true in cases where there is only one
    endpoint.
    """

#     smarts: List[str]
    pass


@add_tag("__component")
class flame_emi:
    def __init__(self, params: Parameters):
        pass

    def __call__(self,
                 smiles: List[str],
                 solvent:str = 'O',
                ) -> np.array:
        scores = flam_predict('emi', [[x, solvent] for x in smiles])
        return ComponentResults([scores])

@add_tag("__component")
class flame_abs:
    def __init__(self, params: Parameters):
        pass

    def __call__(self,
                 smiles: List[str],
                 solvent:str = 'O',
                ) -> np.array:
        scores = flam_predict('abs', [[x, solvent] for x in smiles])
        return ComponentResults([scores])


@add_tag("__component")
class flame_e:
    def __init__(self, params: Parameters):
        pass

    def __call__(self,
                 smiles: List[str],
                 solvent:str = 'O',
                ) -> np.array:
        scores = flam_predict('e', [[x, solvent] for x in smiles])
        return ComponentResults([scores])

@add_tag("__component")
class flame_plqy:
    def __init__(self, params: Parameters):
        pass

    def __call__(self,
                 smiles: List[str],
                 solvent:str = 'O',
                ) -> np.array:
        scores = flam_predict('plqy', [[x, solvent] for x in smiles])
        return ComponentResults([scores])

@add_tag("__component")
class stokes:
    def __init__(self, params: Parameters):
        pass

    def __call__(self,
                 smiles: List[str],
                 solvent:str = 'O',
                ) -> np.array:
        abs_scores = flam_predict('abs', [[x, solvent] for x in smiles])
        emi_scores = flam_predict('emi', [[x, solvent] for x in smiles])
        scores = emi_scores - abs_scores
        scores = scores / 10
        return ComponentResults([scores])